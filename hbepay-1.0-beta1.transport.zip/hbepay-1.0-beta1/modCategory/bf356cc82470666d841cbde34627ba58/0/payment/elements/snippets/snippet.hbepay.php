<?php
return require MODX_CORE_PATH.'components/payment/hbepay.inc.php';